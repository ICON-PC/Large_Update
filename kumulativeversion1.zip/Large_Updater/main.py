import requests
import os
import json

# URL na kontrolu najnovšej verzie
UPDATE_JSON_URL = "https://github.com/ICON-PC/Large_Update/blob/main/updates.json"

# Funkcia na kontrolu aktuálnej verzie
def get_current_version():
    with open("version.txt", "r") as file:
        return file.read().strip()

# Funkcia na kontrolu najnovšej verzie z JSON súboru
def get_latest_version_info():
    response = requests.get(UPDATE_JSON_URL)
    return json.loads(response.text)

# Funkcia na stiahnutie aktualizácie
def download_update(url, filename):
    response = requests.get(url)
    with open(filename, "wb") as file:
        file.write(response.content)

# Hlavná funkcia na kontrolu a inštaláciu aktualizácie
def check_for_updates():
    current_version = get_current_version()
    latest_version_info = get_latest_version_info()
    latest_version = latest_version_info["Version"]
    download_url = latest_version_info["Download_Url"]

    # Vypíše Date, Name a Version
    print(f"Date: {latest_version_info['Date']}")
    print(f"Name: {latest_version_info['Name']}")
    print(f"Version: {latest_version}")

    if current_version != latest_version:
        print(f"New version available: {latest_version}")
        download_update(download_url, "update.zip")
        print("Update downloaded. Please install it manually.")
    else:
        print("You are using the latest version.")

if __name__ == "__main__":
    check_for_updates()